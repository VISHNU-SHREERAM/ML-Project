# Human Stress Level Indicator

This project is done under the course, DS3010: Introduction to Machine Learning
at IIT Palakkad.

Team Members: <br>
    1. <a href="https://github.com/VISHNU-SHREERAM"> Vishnu Shreeram M P  </a> <br>
    2. <a href="https://github.com/cvbshcbad"> Bhupathi Varun </a> <br>
    3. <a href="https://github.com/wanderer3519"> Bhogaraju Shanmukha Sri Krishna </a> <br>

# For more information about this project
link to documentation :- https://docs.google.com/document/d/1IvvKiEwp2-9TxoKfwTvWl_DosPuY50Dz_Opc3-avi7o/edit